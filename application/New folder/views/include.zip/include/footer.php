	<div class="footer">
		  <div class="container">
				<p class="muted credit" style="text-align:center;">Powered by <a href="http://www.creatortechsol.com/" rel="author">Creator IT TechSol Pvt. Ltd.</a>&copy; All Rights Reserved.
		  </div>
	</div>
</body>
</html>
